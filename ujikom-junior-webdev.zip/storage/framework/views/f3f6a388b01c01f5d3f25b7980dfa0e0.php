<footer class="footer py-4">
    <div class="container-fluid">
        <div class="row align-items-center justify-content-center">
            <div class="col-12 text-center">
                <div class="copyright text-sm text-muted">
                    ©Uji-kom Web Developer
                </div>
            </div>
        </div>
    </div>
</footer><?php /**PATH C:\Users\L E X U S\Desktop\ujikom-junior-webdev\resources\views/layouts/partials/footer.blade.php ENDPATH**/ ?>